Implementation of NSGA-II algorithm in form of a python library.
